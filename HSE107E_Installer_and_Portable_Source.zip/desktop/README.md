# HSE107E Desktop v2.5
Projet Electron. Dans ce dossier:
1. `npm install`
2. `npm start`
Pour produire un installateur Windows, ajoutez electron-builder ou utilisez Electron Forge.
