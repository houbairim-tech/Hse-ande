HSE 107E V2.0

Included:
- Existing HSE 107E modules preserved: Dashboard, Actions, Production, GEMBA, Contact Sécurité, Autorisations, EPC, Compte Rendu, custom tabs, presence, settings, timers and existing local image storage.
- Offline-first shell with PWA manifest and service worker.
- Local login/roles: admin/admin123, viewer/viewer123.
- Audit trail for login, save/delete, PTW, LOTO and TBT.
- JSON backup/restore and offline CSV export.
- PTW, Consignation/LOTO and TBT quick registers.
- Storage health panel.
- Desktop installer/launcher scripts.

Important:
This is a local/offline application. The login is a local access gate, not enterprise-grade server authentication. For multi-user synchronization, a backend/API/database is still required.
Full offline XLSX requires SheetJS xlsx.full.min.js in libs/; CSV and JSON work offline without it.
